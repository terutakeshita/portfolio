int X;
int y1,y2,y3;
int en=100;
int a = 150;
int b = 450;
float c = 180;
float d = 520;
float x,y;
PImage ufo,cyan;
boolean visible1 = true;
boolean visible2 = false;

void setup(){
  size(400,700);
  X=100;
  y1=0;
  y2=0;
  y3=0;
  
  cyan=loadImage("cyan.png");
  
  
  ufo=loadImage("ufo.png");
  
}

void draw(){
  background(255);
  strokeWeight(10);
  y1=y1+1;
  y2=y2+1;
  y3=y3+1;
  
  if(y3>height/2)
  y3=y3+10;
  if(y1>height/2)
  y1=y1+20;
  if(y2>=height+30)
  y2=height;
  
  //円
  fill(255,0,0);
  ellipse(X*3+20,y1,en,en);
  fill(255,255,0);
  ellipse(X*2+10,y2,en,en);
  fill(0,255,0);
  ellipse(X,y3,en,en); 
if(y2 >= height){
   y1 = 0;
   y2 = 0;
   y3 = 0;

   a = 150;
   b = 450;
   c = 180;
   d = 520;

   visible1 = true;
   visible2 = false;
 }
  
  x = random(401);
  y = random(701);
  if(visible2){
  image(cyan,x,y);
  }
  if(visible1){
  image(ufo,mouseX,450);
  }
  if(y2 >= 450){
    visible1 = false;
    visible2 = true;
  }
}
  
